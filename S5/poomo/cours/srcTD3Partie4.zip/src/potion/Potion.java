package potion;

import java.util.ArrayList;
import java.util.List;

public class Potion {
	List<Ingredient> listeIngredients = new ArrayList<>();

	public void ajouterIngredient(Ingredient ingredient) {
		// Si la liste est vide
		// Si l'ingr�dient � ajouter n'est pas indispensable
		// Si l'ingr�dient � ajouter est indispensable
		// Si l'ingr�dient � ajouter est un ingr�dient au choix
	}

	public String toString() {
		String chaine = "Les ingr�dients de la potion sont :\n";
		chaine += listeIngredients;
		return chaine;
	}

}
