package potion;

public enum Necessite {
  INDISPENSABLE, AU_CHOIX, OPTIONNEL;
}
