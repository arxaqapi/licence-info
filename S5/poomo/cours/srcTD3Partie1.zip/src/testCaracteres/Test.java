package testCaracteres;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class Test {
	public static void main(String[] args) {
		List<Character> carateres = new ArrayList<>();
		Collections.addAll(carateres, 'r', 'a', 'u', 't');
		Iterator<Character> iter = carateres.iterator();

		System.out.println(carateres);
	}
}
