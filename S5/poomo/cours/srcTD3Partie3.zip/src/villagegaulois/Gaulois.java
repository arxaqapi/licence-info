package villagegaulois;

import village.Personnage;

public class Gaulois extends Personnage{

	public Gaulois(String nom) {
		super(nom);
	}

}
