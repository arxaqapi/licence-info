package equipementromain;

public class Javelot extends Equipement {

  public Javelot(String etat) {
    super(etat, "javelot");
  }

}
