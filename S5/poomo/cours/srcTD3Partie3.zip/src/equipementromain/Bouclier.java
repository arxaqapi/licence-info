package equipementromain;

public class Bouclier extends Equipement {

  public Bouclier(String etat) {
    super(etat, "bouclier");
  }

}
