package testfonctionnel;

import equipementromain.Bouclier;
import equipementromain.Casque;
import musee.RenseignementTrophee;
import villagegaulois.Gaulois;

public class Test {
	public static void main(String[] args) {
		Gaulois asterix = new Gaulois("Ast�rix");

		Bouclier bouclierMordicus = new Bouclier("en bon �tat");
		Casque casqueAerobus = new Casque("caboss�", "fer");

		RenseignementTrophee asterixTrophee1 = new RenseignementTrophee(asterix, bouclierMordicus);
		RenseignementTrophee asterixTrophee2 = new RenseignementTrophee(asterix, casqueAerobus);

		Gaulois proprietaire = asterixTrophee1.getProprietaire();
		System.out.println(proprietaire.getNom() + " poss�de un " + asterixTrophee1.getTrophee());
		proprietaire = asterixTrophee2.getProprietaire();
		System.out.println(proprietaire.getNom() + " poss�de un " + asterixTrophee2.getTrophee());
	}
}
