package equipementromain;

public class Casque extends Equipement {
	
  public Casque(String etat, String matiere) {
    super(etat, "casque");
  }

}
