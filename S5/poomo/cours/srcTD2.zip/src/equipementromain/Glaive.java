package equipementromain;

public class Glaive extends Equipement {

  public Glaive(String etat) {
    super(etat, "glaive");
  }

}
