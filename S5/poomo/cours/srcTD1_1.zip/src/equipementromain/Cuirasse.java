package equipementromain;

public class Cuirasse extends Equipement {

  public Cuirasse(String etat) {
    super(etat, "cuirasse");
  }

}
