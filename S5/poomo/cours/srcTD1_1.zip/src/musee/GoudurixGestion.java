package musee;

import equipementromain.Equipement;
import villagegaulois.Gaulois;

public class GoudurixGestion implements GestionTrophee {
	private Gaulois[] proprietaires = new Gaulois[30];
	private Equipement[] trophees = new Equipement[30];
	private int nombreDeTrophee = 0;

	public void ajouterTrophee(Gaulois proprietaire, Equipement trophee) {
		proprietaires[nombreDeTrophee] = proprietaire;
		trophees[nombreDeTrophee] = trophee;
		nombreDeTrophee++;
	}

	public String lesTrophees(Gaulois proprietaire) {
		String leTrophee = "Le troph�e de " + proprietaire.getNom() + " est ";
		int indiceProprietaire = 0;
		for (int i = 0; i < nombreDeTrophee; i++)
			if (proprietaire.equals(proprietaires[i]))
				indiceProprietaire = i;
		leTrophee += trophees[indiceProprietaire];
		return leTrophee;
	}

	public String tousLesTrophees() {
		String tousLesTrophees = "Tous les troph�es du mus�e sont :\n";
		for (int i = 0; i < nombreDeTrophee; i++)
			tousLesTrophees += "- " + trophees[i] + "\n";
		return tousLesTrophees;
	}
}
