package musee;

import equipementromain.Equipement;
import villagegaulois.Gaulois;

public class KeskonrixGestion implements GestionTrophee {
	private RenseignementTrophee[] trophees = new RenseignementTrophee[30];
	private int nombreDeTrophee = 0;

	public void ajouterTrophee(Gaulois proprietaire, Equipement trophee) {
		trophees[nombreDeTrophee] = new RenseignementTrophee(proprietaire, trophee);
		nombreDeTrophee++;
	}

	public String lesTrophees(Gaulois proprietaire) {
		String tousLesTrophees = "Les troph�es de " + proprietaire.getNom() + " sont :\n";
		for (int i = 0; i < nombreDeTrophee; i++) {
			Gaulois proprietaireTrophee = trophees[i].getProprietaire();
			if (proprietaire.equals(proprietaireTrophee)) {
				Equipement typeEquipement = trophees[i].getTrophee();
				tousLesTrophees += "- " + typeEquipement + "\n";
			}
		}
		return tousLesTrophees;
	}

	public String tousLesTrophees() {
		String tousLesTrophees = "Tous les troph�es du mus�e sont :\n";
		for (int i = 0; i < nombreDeTrophee; i++) {
			Equipement typeEquipement = trophees[i].getTrophee();
			tousLesTrophees += "- " + typeEquipement + "\n";
		}
		return tousLesTrophees;
	}
}
