package musee;

import equipementromain.Equipement;
import villagegaulois.Gaulois;

public class RenseignementTrophee {
	private Gaulois proprietaire;
	private Equipement trophee;

	public RenseignementTrophee(Gaulois proprietaire, Equipement trophee) {
		this.proprietaire = proprietaire;
		this.trophee = trophee;
	}

	public Gaulois getProprietaire() {
		return proprietaire;
	}

	public Equipement getTrophee() {
		return trophee;
	}
}
