package musee;

import equipementromain.Equipement;
import villagegaulois.Gaulois;

public interface GestionTrophee {
	void ajouterTrophee(Gaulois proprietaire, Equipement trophee);

	String tousLesTrophees();

	String lesTrophees(Gaulois proprietaire);
}
