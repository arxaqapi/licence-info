package testfonctionnel;

import equipementromain.Bouclier;
import equipementromain.Casque;
import equipementromain.Glaive;
import musee.GestionTrophee;
import musee.GoudurixGestion;
import musee.Musee;
import villagegaulois.Gaulois;

public class Test {
	public static void main(String[] args) {
		Gaulois asterix = new Gaulois("Ast�rix");
		Gaulois obelix = new Gaulois("Ob�lix");
		Gaulois abraracourcix = new Gaulois("Abraracourcix");

		Bouclier bouclierMordicus = new Bouclier("en bon �tat");
		Casque casqueAerobus = new Casque("caboss�", "fer");
		Glaive glaiveCornedurus = new Glaive("cass�");
		Glaive glaiveAerobus = new Glaive("tordu");
		Casque casqueHumerus = new Casque("bon �tat", "fer");

		GestionTrophee gestionnaireTrophees = new GoudurixGestion();
		Musee musee = new Musee("Museum", gestionnaireTrophees);
		musee.ajouterTrophee(asterix, bouclierMordicus);
		musee.ajouterTrophee(asterix, casqueAerobus);
		musee.ajouterTrophee(asterix, glaiveCornedurus);
		musee.ajouterTrophee(obelix, glaiveAerobus);
		musee.ajouterTrophee(abraracourcix, casqueHumerus);
		System.out.println("Le mus� " + musee.getNom() + " est ouvert !\n");
		System.out.println(musee.tousLesTrophees());
		System.out.println(musee.lesTrophees(asterix));
	}
}
