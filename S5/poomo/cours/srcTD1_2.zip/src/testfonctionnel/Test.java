package testfonctionnel;

import villagegaulois.Gaulois;
import villagegaulois.VillageGaulois;

public class Test {
	public static void main(String[] args) {
		Gaulois abraracourcix = new Gaulois("Abraracourcix");
		VillageGaulois villageGaulois = new VillageGaulois("village des irr�ductibles Gaulois.", abraracourcix);
		Gaulois bonemine = new Gaulois("Bonemine");
		// Ajouter une hutte pour 3 personnes maximum

		// Ajouter abraracourcix et bonemine dans cette hutte

		// Afficher les villageois
	}
}
