package village;

public class Personnage {
  protected String nom;

  public Personnage(String nom) {
    this.nom = nom;
  }

 
  public String getNom() {
    return nom;
  }

}
