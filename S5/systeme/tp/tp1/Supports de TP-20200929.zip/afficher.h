#ifndef AFFICH_H
#define AFFICH_H

void afficher(void);

#endif
