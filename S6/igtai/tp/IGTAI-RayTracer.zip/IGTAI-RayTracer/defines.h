#ifndef __DEFINES_H__
#define __DEFINES_H__

#define TP11
#define TP12
#define TP13
#define TP14
#define TP15
#define TP21
#define TP22
#define TP23
#define TP23TR
#define TP24
#define TP31
#define TP32
#define IMP
#undef  TP23TR
//#define SAMPLEGLOSSY

#include <stdbool.h>
#include <glm/glm.hpp>
#include <glm/gtc/constants.hpp>
using namespace glm;

typedef vec3 point3;
typedef vec3 color3;

#endif
