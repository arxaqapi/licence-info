/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package phf;
import CardsLayout.StaticLayout;

/**
 *
 * @author knt3258a
 */
public class Phf {

    /** Rend la page visible
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        StaticLayout site = new StaticLayout();
        site.setVisible(true);
    }
    
}
