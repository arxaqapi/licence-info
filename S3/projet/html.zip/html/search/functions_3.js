var searchData=
[
  ['dist_5feuclidienne',['dist_euclidienne',['../tsp__tools_8c.html#a2716497c53463eb2fdbebdb693bbb52b',1,'tsp_tools.c']]],
  ['dist_5fmat',['dist_mat',['../tsp__tools_8c.html#af681a619d3db4dac494db039dc8da3a0',1,'tsp_tools.c']]]
];
